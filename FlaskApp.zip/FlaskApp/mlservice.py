#!/usr/bin/python
import sys,os
#import logging
wsgidir=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,wsgidir)
print('wsgidir',wsgidir)
#activate_this = '/home/analytics/dolceravenv/bin/activate_this.py'
#execfile(activate_this, dict(__file__=activate_this))
from app import app as application
application.secret_key = 'dolcera123'
